# StegApp

### Instructions:

- <code>cd src/</code>
- <code>flask run</code>
- Make sure to go to <a href = "https://localhost:5000/">localhost:5000</a>

## Files to not give a fuck about/Delete:
- .dockerignore
- stopandremove.sh
- docker-entrypoint.sh
- docker-compose.yml
- Dockerfile


